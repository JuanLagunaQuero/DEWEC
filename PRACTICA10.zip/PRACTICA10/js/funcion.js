/* son 9 piezas coordenadas
Arriba Derecha      : (0,0)
Arriba Centro       : (0,1)
Arriba Izquierda    : (0,2)
Medio Derecha       : (1,0)
Medio Centro        : (1,1)
Medio Izquierda     : (1,2)
Abajo Derecha       : (2,0)
Abajo Medio         : (2,1)
Abajo Izquierda     : (2,2)

hueco vacio en Centro : H=(1,1) */

creapiezas = function(fila, columna){

   

    

    document.body.appendChild(div);
}


