<?php
   $nombre=$_GET["nombre"];
   $apellidos=$_GET["apellidos"];
   echo "HOLA ${nombre} ${apellidos} como te encuentras hoy";
?>